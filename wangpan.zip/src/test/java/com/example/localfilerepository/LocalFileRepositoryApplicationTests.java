package com.example.localfilerepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalFileRepositoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
